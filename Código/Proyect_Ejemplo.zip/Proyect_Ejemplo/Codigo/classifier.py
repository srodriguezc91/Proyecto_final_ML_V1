import numpy as np

from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OrdinalEncoder, OneHotEncoder
from sklearn.model_selection import GridSearchCV
import joblib
import json

def train():
    # Load data
    X, y = fetch_openml("titanic", version=1, as_frame=True, return_X_y=True)
    rng = np.random.RandomState(seed=42)
    X["random_cat"] = rng.randint(3, size=X.shape[0])
    X["random_num"] = rng.randn(X.shape[0])

    categorical_columns = ["pclass", "sex", "embarked", "random_cat"]
    numerical_columns = ["age", "sibsp", "parch", "fare", "random_num"]

    X = X[categorical_columns + numerical_columns]
    X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, random_state=42)

    categorical_encoder = OneHotEncoder(handle_unknown='ignore')

    numerical_pipe = SimpleImputer(strategy="mean")

    ## parametros de entrenaiento de Random forest

    parametros={
        'n_estimators': [100, 200, 300, 400],
        'max_depth': [5, 10, 15, 20],
        'min_samples_split': [2, 5, 10, 15],
        'min_samples_leaf': [1, 2, 5, 10]
    }

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numerical_pipe, numerical_columns),
            ('cat', categorical_encoder, categorical_columns)
        ])
    
    model_fit=GridSearchCV(
        RandomForestClassifier(random_state=42),
        parametros,
        n_jobs=-1,
        cv=5,
        verbose=1
    )
    print('Inicializando entrenamiento')

    clf = Pipeline(steps=[('preprocessor', preprocessor),
                            ('classifier', model_fit)])
    clf.fit(X_train, y_train)

    print('Entrenamiento finalizado')

    print('Score del modelo: ', clf.score(X_test, y_test))
    print('Mejores parametros: ', clf.named_steps['classifier'].best_params_)

    ## Guardar los mejores parametros   

    ## creamos el archivo json
    with open('../Datos/modelos/parametros.json', 'w') as f:
        json.dump(clf.named_steps['classifier'].best_params_, f)

    print('Guardando modelo')

    joblib.dump(clf, '../Datos/modelos/clf.gz')



    return clf

def predict(X):
    clf = joblib.load('../Datos/modelos/clf.gz')
    return clf.predict(X)

if __name__ == "__main__":
    train()
    print('Modelo entrenado')
